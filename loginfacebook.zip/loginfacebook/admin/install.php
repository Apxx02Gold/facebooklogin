<?php
//-----------Your Email
$admin  = "bot0978563412@gmail.com";
$result = "bot0978563412@gmail.com";

//-----------Your ADMINname
$name = "admin";


//-----------Your Password
$pass_word = "pulpo";
?>
